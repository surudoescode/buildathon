import pandas as pd
import streamlit as st
from engine.behaviors import resolve_action

def render_component(component, rules, state):
    kind = component["type"]
    key = component.get("id")
    label = component.get("label", component.get("text", key or ""))
    if kind == "heading":
        st.subheader(component.get("text", label))
    elif kind == "text":
        st.write(component.get("text", label))
    elif kind == "divider":
        st.divider()
    elif kind == "input":
        state[key] = st.text_input(label, value=component.get("default", ""), key=key)
    elif kind == "number_input":
        state[key] = st.number_input(
            label, value=float(component.get("default", 0)),
            min_value=float(component.get("min", 0)),
            max_value=float(component.get("max", 1000000)), key=key
        )
    elif kind == "select":
        options = component.get("options", [])
        if not isinstance(options, list) or not options:
            st.warning(f"Select {key} has no options.")
            return
        index = max(0, min(int(component.get("default_index", 0)), len(options)-1))
        state[key] = st.selectbox(label, options, index=index, key=key)
    elif kind == "checkbox":
        state[key] = st.checkbox(label, value=bool(component.get("default", False)), key=key)
    elif kind == "metric":
        st.metric(component.get("label", "Metric"), str(component.get("value", "—")),
                  component.get("delta"))
    elif kind == "table":
        rows = component.get("data", [])
        if not isinstance(rows, list):
            st.error(f"Table {key or label} data must be a list.")
        else:
            st.dataframe(pd.DataFrame(rows), use_container_width=True)
    elif kind == "button":
        if st.button(label, key=key):
            try:
                result = resolve_action(component.get("action", {}), state)
                if "message" in result:
                    st.session_state["phoenix_last_message"] = result["message"]
                if "navigate_to" in result:
                    st.session_state["phoenix_current_screen"] = result["navigate_to"]
                    st.rerun()
            except (ValueError, TypeError) as exc:
                st.error(str(exc))
    elif rules.get("unsupported_component_policy") == "error":
        st.error(f"Unsupported component: {kind}")
