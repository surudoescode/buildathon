import json
from pathlib import Path

DEFAULT_RULES = {
    "page_title": "Phoenix Reconstructed App",
    "layout": "wide",
    "show_debug": False,
    "unsupported_component_policy": "error"
}

def load_rules(path):
    try:
        with Path(path).open(encoding="utf-8") as file:
            rules = json.load(file)
    except FileNotFoundError as exc:
        raise ValueError(f"Rules file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Rules file is not valid JSON: {exc}") from exc
    if not isinstance(rules, dict):
        raise ValueError("Rules must be a JSON object.")
    result = {**DEFAULT_RULES, **rules}
    if result["layout"] not in {"centered", "wide"}:
        raise ValueError("layout must be centered or wide.")
    if result["unsupported_component_policy"] not in {"error", "skip"}:
        raise ValueError("unsupported_component_policy must be error or skip.")
    return result
