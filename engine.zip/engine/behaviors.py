def validate_number(value, label="Value", minimum=None, maximum=None):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{label} must be a number.")
    if minimum is not None and value < minimum:
        raise ValueError(f"{label} must be at least {minimum}.")
    if maximum is not None and value > maximum:
        raise ValueError(f"{label} must be at most {maximum}.")
    return value

def calculate_total(quantity, unit_price):
    validate_number(quantity, "Quantity", minimum=0)
    validate_number(unit_price, "Unit price", minimum=0)
    return quantity * unit_price

def resolve_action(action, state):
    if not isinstance(action, dict):
        raise ValueError("Action must be an object.")
    kind = action.get("type")
    if kind == "set_message":
        return {"message": str(action.get("message", ""))}
    if kind == "calculate_total":
        qkey = action.get("quantity_key", "quantity")
        pkey = action.get("price_key", "unit_price")
        if qkey not in state or pkey not in state:
            raise ValueError("Calculation action refers to a missing input.")
        return {"message": f"Total: {calculate_total(state[qkey], state[pkey]):g}"}
    if kind == "navigate":
        target = action.get("screen")
        if not isinstance(target, str) or not target:
            raise ValueError("Navigate action needs a screen id.")
        return {"navigate_to": target}
    raise ValueError(f"Unsupported action type: {kind!r}")
