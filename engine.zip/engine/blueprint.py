import json
from pathlib import Path

SUPPORTED_COMPONENTS = {
    "heading", "text", "input", "number_input", "select",
    "checkbox", "button", "metric", "table", "divider"
}

def load_blueprint(path):
    try:
        with Path(path).open(encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError as exc:
        raise ValueError(f"Blueprint file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Blueprint is not valid JSON: {exc}") from exc

def validate_blueprint(blueprint):
    if not isinstance(blueprint, dict):
        raise ValueError("Blueprint must be a JSON object.")
    if not isinstance(blueprint.get("application"), str) or not blueprint["application"].strip():
        raise ValueError("Blueprint needs a non-empty application name.")
    screens = blueprint.get("screens")
    if not isinstance(screens, list) or not screens:
        raise ValueError("Blueprint needs a non-empty screens list.")
    ids = set()
    for screen in screens:
        if not isinstance(screen, dict):
            raise ValueError("Each screen must be an object.")
        sid = screen.get("id")
        if not isinstance(sid, str) or not sid.strip():
            raise ValueError("Every screen needs a non-empty string id.")
        if sid in ids:
            raise ValueError(f"Duplicate screen id: {sid}")
        ids.add(sid)
        if not isinstance(screen.get("components", []), list):
            raise ValueError(f"Screen {sid}: components must be a list.")
        for component in screen.get("components", []):
            if not isinstance(component, dict):
                raise ValueError(f"Screen {sid}: each component must be an object.")
            kind = component.get("type")
            if kind not in SUPPORTED_COMPONENTS:
                raise ValueError(f"Unsupported component type {kind!r} on screen {sid}.")
            if kind in {"input", "number_input", "select", "checkbox", "button"}:
                if not isinstance(component.get("id"), str) or not component["id"].strip():
                    raise ValueError(f"{kind} component needs a non-empty id.")
    return True
