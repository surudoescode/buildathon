import unittest
from engine.behaviors import calculate_total, resolve_action

class BehaviorTests(unittest.TestCase):
    def test_calculation(self):
        self.assertEqual(calculate_total(3, 100), 300)

    def test_negative_values_rejected(self):
        with self.assertRaises(ValueError):
            calculate_total(-1, 10)

    def test_calculation_action(self):
        result = resolve_action(
            {"type": "calculate_total", "quantity_key": "q", "price_key": "p"},
            {"q": 2, "p": 5}
        )
        self.assertEqual(result["message"], "Total: 10")

if __name__ == "__main__":
    unittest.main()
