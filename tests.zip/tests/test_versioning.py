import json
import tempfile
import unittest
from pathlib import Path

class VersionIsolationTests(unittest.TestCase):
    def test_candidate_copy_does_not_change_baseline(self):
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder) / "baseline.json"
            candidate = Path(folder) / "candidate.json"
            base.write_text('{"rule": 1}', encoding="utf-8")
            candidate.write_text(base.read_text(encoding="utf-8"), encoding="utf-8")
            candidate.write_text('{"rule": 2}', encoding="utf-8")
            self.assertEqual(json.loads(base.read_text(encoding="utf-8"))["rule"], 1)
            self.assertEqual(json.loads(candidate.read_text(encoding="utf-8"))["rule"], 2)

if __name__ == "__main__":
    unittest.main()
