import tempfile
import unittest
from pathlib import Path
from engine.blueprint import load_blueprint, validate_blueprint
from engine.rules import load_rules
from engine.generator import generate_app

ROOT = Path(__file__).resolve().parents[1]

class ReconstructionTests(unittest.TestCase):
    def test_example_blueprint_validates(self):
        self.assertTrue(validate_blueprint(load_blueprint(ROOT / "data" / "blueprint.json")))

    def test_unknown_component_is_rejected(self):
        data = {"application": "Test", "screens": [
            {"id": "home", "components": [{"type": "magic"}]}
        ]}
        with self.assertRaisesRegex(ValueError, "Unsupported component"):
            validate_blueprint(data)

    def test_generator_writes_file(self):
        blueprint = load_blueprint(ROOT / "data" / "blueprint.json")
        rules = load_rules(ROOT / "data" / "rules.json")
        with tempfile.TemporaryDirectory() as folder:
            output = generate_app(blueprint, rules, Path(folder) / "generated_app.py")
            self.assertTrue(output.exists())
            self.assertIn("Phoenix Demo", output.read_text(encoding="utf-8"))

if __name__ == "__main__":
    unittest.main()
