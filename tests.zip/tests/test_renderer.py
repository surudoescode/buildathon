import unittest
from engine.blueprint import SUPPORTED_COMPONENTS

class RendererContractTests(unittest.TestCase):
    def test_supported_component_contract(self):
        self.assertTrue({"heading", "text", "input", "number_input", "select",
                         "checkbox", "button", "metric", "table", "divider"}
                        .issubset(SUPPORTED_COMPONENTS))

if __name__ == "__main__":
    unittest.main()
